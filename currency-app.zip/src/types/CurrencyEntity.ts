export interface CurrencyEntity {
    id: string;
    iso: string;
    symbol: string;
}